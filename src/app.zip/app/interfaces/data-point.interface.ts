export interface DataPoint {
    y: number;
    y2?:number;
    y3?:number;
    y4?:number;
    x: Date;
}
