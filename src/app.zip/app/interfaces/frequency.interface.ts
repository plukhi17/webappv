export interface RawFrequency {
    transformedData: number[];
    divideValue: number;
}


export interface Frequency {
    f: number;
    v: number;
}
