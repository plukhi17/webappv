export interface AvgFrequency {
    avg_frequency_val: number;
    telemetry_time: string;
}
