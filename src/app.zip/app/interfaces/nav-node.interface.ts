export interface NavNode {
    icon: string;
    name: string;
    path: string;
}
