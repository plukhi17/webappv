export interface MachineFault {
    fault_id: number;
    fault_name: string;
    fault_frequencies: number[];
}
