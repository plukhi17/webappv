export interface IrmsFrequency {
    i_rms: number;
    telemetry_time: string;
}
