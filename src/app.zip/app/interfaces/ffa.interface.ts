export interface FfaFrequency {
    telemetry_time_utc: string;
    max_value: string;
    max_index_value_new: string;
    i_rms: string;
    riskscore: string;
}