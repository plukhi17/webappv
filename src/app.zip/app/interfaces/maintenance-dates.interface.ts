export interface MaintenanceDates {
    equipment_id: number;
    maintenance_date: string;
}