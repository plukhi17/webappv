export abstract class RouteConstant {

    /* Auth Module */
    static readonly AUTH = '/auth';
    static readonly LOGIN = '/auth/login';

    /* Console Module */
    static readonly CONSOLE = '/console';

    /* Dashboard Module */
    static readonly DASHBOARD = '/console/machine-insights';

    // // Analytic Module
    // static readonly ANALYTICS = '/console/overview';

    // Analytic Module
    static readonly ANALYTICS = '/console/machine-insights';

}
