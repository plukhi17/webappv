export abstract class StorageConstant {
    static readonly ID_TOKEN = 'idToken';
    static readonly PLANT_ID = 'plantId';
    static readonly TENANT_ID = 'tenantId';
}
